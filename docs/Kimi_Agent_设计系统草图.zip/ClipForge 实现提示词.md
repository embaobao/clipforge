# ClipForge 设计语言 · 实现提示词（终版）

> **使用方式（二选一）**
> 1. 把本文件**全文粘贴**给 Kimi Code，开头加一句："按本文档重构 ClipForge 的样式与交互层"。
> 2. 把本文件存为项目根目录 `docs/DESIGN.md`，对 Kimi Code 说："阅读 docs/DESIGN.md 并严格执行"。
>
> 本提示词基于已确认的灰阶 Spotlight 预览版（shadcn/ui × Tailwind），所有数值均为终稿，不要自行更改配色与尺寸。

---

## 一、角色与任务

你是 ClipForge 的前端工程师。ClipForge 是跨平台（macOS 优先、兼容 Windows/Linux）的剪贴板历史工具：**Tauri v2 + React 19 + TypeScript + Vite**。全局热键 `Ctrl+V` 呼出 480px 浮动面板 → 浏览/搜索历史 → 点击或回车复制回贴。产品定位："Clipy 的能力 + Raycast 的质感"。

**任务边界：只重构视觉与交互层。**
- 不改业务逻辑、数据流、Tauri 命令、状态管理、DOM 结构级工作流。
- 引入 Tailwind CSS + shadcn/ui 作为样式基础设施。
- 现有 `src/App.css` **整体废弃**（迁移完成后删除该文件及其 import）。

## 二、硬约束

1. 面板宽 480px（允许 420–500px）；呼出 → 粘贴热路径 P95 ≤ 300ms。
2. **纯灰阶**：禁止任何彩色主题色（无蓝/绿/紫/橙）。唯一的彩色允许项：破坏性操作用 `text-destructive`（仅文字）、macOS 窗口红绿灯。
3. 双主题 light/dark，跟随系统，`.dark` class 切换，禁止闪烁。
4. 中文优先 UI；字体用系统栈，不引外部字体。
5. 动画只动 `transform` / `opacity`；尊重 `prefers-reduced-motion` 与 `prefers-reduced-transparency`。
6. `backdrop-filter` 只允许出现在浮动面板这一层，禁止多层 blur/saturate 叠加。
7. 图标一律 lucide-react（1.8–2px stroke），禁止 emoji 图标。

## 三、技术栈改造

```bash
npm i tailwindcss@3.4 postcss autoprefixer \
      class-variance-authority clsx tailwind-merge \
      lucide-react sonner cmdk
npx shadcn@latest init        # style: new-york, base color: zinc, CSS variables: yes
npx shadcn@latest add button dropdown-menu switch slider select toggle-group separator scroll-area tooltip
```

- `tailwind.config.js`：`darkMode: ["class"]`，颜色映射到 `hsl(var(--token))`。
- 删除 `src/App.css`；全局样式全部收敛到 `src/index.css`（第四节给出全量内容，直接覆盖）。

## 四、设计令牌（index.css 全量，直接复制）

语义映射（用途不许换）：

| 语义 | 浅色 | 深色 | 用途 |
|---|---|---|---|
| `background` | `#FFFFFF` | `#09090B` | 页面/窗口底 |
| `foreground` | `#18181B` | `#FAFAFA` | 主文字 |
| `muted-foreground` | `#71717A` | `#A1A1AA` | 次级文字、meta、快捷键、序号 |
| `accent`（选中） | 黑 4.5% | 白 7% | **选中行填充，全界面唯一选中语言** |
| 发丝线 | 黑 5% | 白 7% | 唯一的分隔手段 |
| `primary` | `#18181B` | `#FAFAFA` | 仅：主按钮、Switch 开、Slider、scope 选中圆、Toast |
| 面板材质 | 白 78% + blur(28px) saturate(180%) | `#1C1C1E` 80% + 同 blur | 仅浮动面板 |

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 240 10% 3.9%;
    --card: 0 0% 100%;
    --card-foreground: 240 10% 3.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 240 10% 3.9%;
    --primary: 240 5.9% 10%;
    --primary-foreground: 0 0% 98%;
    --secondary: 240 4.8% 95.9%;
    --secondary-foreground: 240 5.9% 10%;
    --muted: 240 4.8% 95.9%;
    --muted-foreground: 240 3.8% 46.1%;
    --accent: 240 4.8% 95.9%;
    --accent-foreground: 240 5.9% 10%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 0 0% 98%;
    --border: 240 5.9% 90%;
    --input: 240 5.9% 90%;
    --ring: 240 5.9% 10%;
    --radius: 0.625rem;
  }
  .dark {
    --background: 240 10% 3.9%;
    --foreground: 0 0% 98%;
    --card: 240 10% 3.9%;
    --card-foreground: 0 0% 98%;
    --popover: 240 10% 3.9%;
    --popover-foreground: 0 0% 98%;
    --primary: 0 0% 98%;
    --primary-foreground: 240 5.9% 10%;
    --secondary: 240 3.7% 15.9%;
    --secondary-foreground: 0 0% 98%;
    --muted: 240 3.7% 15.9%;
    --muted-foreground: 240 5% 64.9%;
    --accent: 240 3.7% 15.9%;
    --accent-foreground: 0 0% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 0 0% 98%;
    --border: 240 3.7% 15.9%;
    --input: 240 3.7% 15.9%;
    --ring: 240 4.9% 83.9%;
  }
}

@layer base {
  * { @apply border-border; }
  body {
    @apply bg-background text-foreground;
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "PingFang SC",
      "Segoe UI", "Microsoft YaHei", "Noto Sans SC", sans-serif;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
  }
  ::selection { background: rgb(0 0 0 / 0.12); }
  .dark ::selection { background: rgb(255 255 255 / 0.18); }
}

/* 等宽数字/快捷键：mono + tabular-nums */
.mono {
  font-family: ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace;
  font-feature-settings: "tnum";
  letter-spacing: -0.01em;
}

/* macOS 材质：仅面板一层 */
.material {
  background: rgb(255 255 255 / 0.78);
  -webkit-backdrop-filter: blur(28px) saturate(180%);
  backdrop-filter: blur(28px) saturate(180%);
}
.dark .material { background: rgb(28 28 30 / 0.8); }

/* 面板投影：0.5px 描边光 + 双层软阴影，无可见边框 */
.panel-shadow {
  box-shadow: 0 0 0 0.5px rgb(0 0 0 / 0.05),
    0 8px 24px -8px rgb(0 0 0 / 0.1), 0 24px 64px -16px rgb(0 0 0 / 0.14);
}
.dark .panel-shadow {
  box-shadow: 0 0 0 0.5px rgb(255 255 255 / 0.1),
    0 8px 24px -8px rgb(0 0 0 / 0.5), 0 24px 64px -16px rgb(0 0 0 / 0.5);
}
.window-shadow {
  box-shadow: 0 0 0 0.5px rgb(0 0 0 / 0.06),
    0 16px 48px -12px rgb(0 0 0 / 0.16), 0 40px 96px -24px rgb(0 0 0 / 0.12);
}
.dark .window-shadow {
  box-shadow: 0 0 0 0.5px rgb(255 255 255 / 0.1),
    0 16px 48px -12px rgb(0 0 0 / 0.55), 0 40px 96px -24px rgb(0 0 0 / 0.5);
}

/* 弹簧曲线：damping 1.0 / response 0.4 → cubic-bezier(0.32, 0.72, 0, 1) */
@keyframes panel-in {
  from { opacity: 0; transform: translateY(12px) scale(0.965); }
}
.panel-in { animation: panel-in 0.45s cubic-bezier(0.32, 0.72, 0, 1) both; }

@keyframes row-in { from { opacity: 0; } }
.row-in { animation: row-in 0.18s ease-out both; }

.thin-scroll::-webkit-scrollbar { width: 6px; }
.thin-scroll::-webkit-scrollbar-thumb { background: rgb(0 0 0 / 0.14); border-radius: 3px; }
.dark .thin-scroll::-webkit-scrollbar-thumb { background: rgb(255 255 255 / 0.16); }
.thin-scroll::-webkit-scrollbar-track { background: transparent; }

@media (prefers-reduced-motion: reduce) {
  .panel-in, .row-in { animation: none; }
  * { transition-duration: 0.01ms !important; }
}
@media (prefers-reduced-transparency: reduce) {
  .material { background: rgb(250 250 250); backdrop-filter: none; -webkit-backdrop-filter: none; }
  .dark .material { background: rgb(24 24 26); }
}
```

**字号阶梯**：11px mono（辅助/快捷键）· 12.5px（设置/菜单）· 13px（列表主文本）· 15px（搜索输入）· 20px+（区块标题，`tracking -0.02em`）。
**圆角**：行 8 · 卡片/预览 10 · 面板 14 · 设置窗口 12 · 圆钮 999。
**间距**：4px 网格，常用 4/8/12/16。

## 五、组件规格

### 1. 快速面板（核心，480px）

容器：`w-[480px] rounded-[14px] material panel-shadow overflow-hidden panel-in`。

- **搜索栏**（h-52px，px-4，裸奔无边框）：Search 图标 15px muted → input（15px，`bg-transparent outline-none`，占位符 50% 透明度）→ 右侧 scope 圆钮组。
- **scope 圆钮**（28px 圆形）：历史 Clock / 收藏 Star / 片段 Scissors / 更多 MoreHorizontal。选中 = `bg-foreground text-background` 实心圆；未选 = muted 图标 + hover 黑 5% 底。按压 `active:scale-90`。
- **分隔**：搜索栏与列表、列表与底栏之间各一条发丝线（黑 5% / 白 7%），这是全界面仅有的线。
- **组头**：`px-3 pt-2.5 pb-1`，11px medium muted 组名 + 右侧 mono 计数。
- **结果行**（h-44px，rounded-8，px-2，gap-3）：
  - 左：类型图标块 28×28 rounded-7（黑 4% 底）+ 13.5px muted 图标（text→Type / image→Image / link→Link2 / doc→FileText / table→Table2）。
  - 中：13px 主文本 truncate（固定项前置 12px Pin 图标）+ 11px muted meta（来源 · 时间）。
  - 右（mono 11px muted）：默认显序号 `1–9`；**当前选中行显 `⏎`**；hover 整行时替换为三个 24px 图标钮（收藏 Star / 固定 Pin / 更多 MoreHorizontal）；复制成功后 1.4s 内显 `✓ 已复制`。
  - 选中态：`bg-black/[0.045]`（dark `bg-white/[0.07]`），**无描边、无黑块、无色条**。
  - 反馈：行 `active:scale-[0.99]`，过渡只动 background-color 100ms。
- **底栏**（h-36px，px-3.5，发丝顶线）：左侧 `N 条 · ⌘K 全部操作`（mono 11px，可点击开菜单）；右侧 mono 10.5px muted：`↑↓ 浏览 · ⏎ 粘贴 · 空格 预览 · / 搜索`。

### 2. 快速预览（空格触发）

列表上方插卡：`mx-2 mt-2 rounded-[10px] bg-black/[0.03] p-3.5`。内容：28px 图标块 + 完整内容（13px，可多行）+ mono meta（含字符数）；底部发丝线 + 操作行：主按钮 `粘贴 ⏎`（h-6，primary）、ghost `纯文本 ⇧⏎`、ghost `收藏 ⌘D`。

### 3. ⌘K 全部操作菜单

shadcn `DropdownMenu`，`side="top"`，`w-52 rounded-xl p-1`，菜单项 `rounded-lg text-[12.5px]`，快捷键用 `DropdownMenuShortcut` + `.mono` 右对齐：
粘贴为纯文本 `⇧⏎` · 固定到顶部 `⌘P` · 收藏 `⌘D` · ─ · 新建片段 `⌘N` · 移到文件夹… · ─ · 删除 `⌫`（`text-destructive`）。

### 4. Toast

sonner，`position="top-center"`，rounded-10，13px。复制成功：`已复制到剪贴板` + 内容摘要（42 字截断）。

### 5. 空状态

圆底 SearchX 图标（40px 圆，黑 4% 底）+ `没有匹配的结果`（13px medium）+ 引导文案（12px muted：`换个关键词，或按 ⌘N 把当前内容存为新片段`）+ outline 按钮 `新建片段 ⌘N`。

### 6. 多选批量

入选行复用选中填充（不新增颜色）；底栏整体切换为：左 `已选 N 项`，右 `⏎ 合并粘贴 · ⌫ 删除 · esc 取消`。

### 7. 设置窗口（680px）

容器：`w-[680px] rounded-[12px] bg-card window-shadow`。
- 标题栏 h-44px：左侧 macOS 红绿灯（11px 圆，`#FF5F57/#FEBC2E/#28C840`），居中 13px medium「设置」。
- 侧栏 172px（黑 2% 底，右侧发丝线）：通用 Settings2 / 快捷键 Keyboard / 历史与隐私 History / 片段与文件夹 Scissors / 外观 Monitor / 关于 Info。项 h-32px rounded-6，选中 `bg-black/[0.06]` medium。
- 内容行式表单（label 13px + desc 11.5px muted 居左，控件居右，行间发丝线 4%）：
  全局快捷键（mono 键值 `⌃ V`，黑 5% 圆角底 + ghost「重新录制」）· Switch×3（开机启动 / 菜单栏图标 / 提示音）· 主题三段（跟随系统/浅色/深色，ToggleGroup，选中白色药丸 + shadow-sm）· 密度两段（紧凑/舒适）· 历史容量 Slider（100–5000 step 100，右 mono 数值 `2,000 条`）· 自动清理 Select（从不/7/30/90 天）· 粘贴目标 Select（当前前台应用/上次使用/每次询问）。
- 底部：左 mono 10.5px muted 版本号，右 ghost「恢复默认」「导出数据…」。

### 8. 其余视图（功能全保留，语言全复用）

详情页（编辑器 + AI 区）、回收站 / 片段 / 文件夹视图、引导页、托盘菜单：**复用本文件全部令牌、字号、圆角、阴影、动效**，不引入任何新颜色、新圆角、新阴影、新组件样式。敏感内容遮罩用 `blur(8px)` 单值即可。

## 六、键盘映射（面板作用域，全局监听）

| 按键 | 行为 |
|---|---|
| `↑` `↓` | 移动选中行（hover 同步选中） |
| `⏎` | 复制当前行并回贴（toast + 行内「已复制」） |
| `1–9` | 输入框**未聚焦**时：直接粘贴第 n 条 |
| `空格` | 输入框未聚焦时：开关快速预览 |
| `/` | 聚焦搜索框 |
| `⌘K` | 开/关全部操作菜单 |
| `⌘D` / `⌘P` / `⌘N` | 收藏 / 固定 / 新建片段 |
| `⇧⏎` | 粘贴为纯文本 |
| `esc` | 逐层退出：关菜单 → 关预览 → 清空搜索词 → 输入框失焦 → 关闭面板 |

规则：输入框聚焦时数字与空格照常进文本；所有快捷键提示一律纯文本 `.mono`，禁止 keycap 盒子。

## 七、动效规格

| 场景 | 参数 |
|---|---|
| 按压反馈 | `scale(0.98)`（按钮 `0.9`–`0.98`），100ms ease-out，pointer-down 即时 |
| 行选中 | 仅 background-color 过渡 100ms |
| 面板弹出 | 450ms `cubic-bezier(0.32, 0.72, 0, 1)`，`translateY(12px) scale(0.965)` → 归位 |
| 菜单展开 | 180ms，从触发点缩放（Radix origin-aware 默认行为） |
| 行进入 | 120ms opacity，20ms 级联 |
| 降级 | `prefers-reduced-motion` 关闭全部动画；`prefers-reduced-transparency` 关闭材质 |

## 八、禁止事项（违反即返工）

1. 禁止彩色主题色（尤其蓝色）；禁止纯黑块选中；禁止行描边 / 虚线框 / 左侧色条。
2. 禁止 keycap 盒子样式的快捷键；禁止 emoji 图标。
3. 禁止卡片套卡片：分区只用间距 + 发丝线。
4. 禁止 hover 放大 / 图片旋转 / 无意义入场动效 / marquee。
5. 禁止多层 `backdrop-filter` 叠加；禁止给面板加可见边框（用 0.5px 描边光 + 软阴影）。
6. 禁止引入外部字体；中文禁用斜体。

## 九、实施步骤（按序执行）

1. 安装依赖，`shadcn init`（zinc / CSS 变量），add 所需组件。
2. 用第四节全量覆盖 `src/index.css`；删除 `App.css` 及其 import。
3. 重写快速面板（规格 1–6 + 键盘映射）。
4. 重写设置窗口（规格 7）。
5. 迁移详情页 / 回收站 / 片段 / 文件夹 / 引导 / 托盘（规格 8）。
6. 对照第十节验收清单全量走查。

## 十、验收清单

- [ ] `Ctrl+V` 呼出 → 粘贴完成，热路径 P95 ≤ 300ms；面板宽 480px。
- [ ] 全界面无任何彩色；选中态只有 4.5% 灰填充；搜索框无边框；分隔仅发丝线。
- [ ] 第六节键盘映射全部可用，`esc` 严格逐层退出。
- [ ] light/dark 跟随系统切换无闪烁；`prefers-reduced-motion` 下无动画。
- [ ] 功能回归全过：搜索语法与建议、多选、右键菜单、密度切换（紧凑 34px / 舒适 44px）、详情编辑、AI 区、回收站、片段、文件夹、设置、引导、托盘。
- [ ] `App.css` 已删除，样式只存在于 `index.css` + Tailwind 工具类 + shadcn 组件。
