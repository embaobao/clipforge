import { useEffect, useState, type ReactNode } from "react"
import { Moon, Scissors, Sun } from "lucide-react"
import { Toaster } from "@/components/ui/sonner"
import { ClipPanel } from "@/sections/clip-panel"
import { SettingsWindow } from "@/sections/settings-window"
import { SpecSheet } from "@/sections/spec-sheet"

function Section({
  no, title, desc, children, className = "",
}: {
  no: string; title: string; desc: string; children: ReactNode; className?: string
}) {
  return (
    <section className={`pt-20 ${className}`}>
      <p className="mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground/70">{no}</p>
      <h2 className="mt-2 text-[22px] font-semibold tracking-[-0.02em]">{title}</h2>
      <p className="mt-1.5 max-w-[52ch] text-[13px] leading-relaxed text-muted-foreground">{desc}</p>
      <div className="mt-8">{children}</div>
    </section>
  )
}

const HINTS = ["↑↓ 选择", "⏎ 复制", "1–9 直选", "空格 预览", "⌘K 菜单", "/ 搜索"]

export default function App() {
  const [dark, setDark] = useState(false)
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark)
  }, [dark])

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-foreground dark:bg-[#09090B]">
      <Toaster position="top-center" toastOptions={{ style: { borderRadius: "10px", fontSize: "13px" } }} />

      {/* 顶栏 */}
      <header className="material sticky top-0 z-20 border-b border-black/[0.05] dark:border-white/[0.07]">
        <div className="mx-auto flex h-12 max-w-6xl items-center gap-2.5 px-6">
          <span className="grid h-6 w-6 place-items-center rounded-[7px] bg-foreground text-background">
            <Scissors className="h-3 w-3" strokeWidth={2.2} />
          </span>
          <span className="text-[13.5px] font-semibold tracking-[-0.01em]">ClipForge</span>
          <span className="mono ml-1 hidden text-[11px] text-muted-foreground/70 sm:block">
            设计预览 v5 · shadcn/ui × Tailwind
          </span>
          <div className="flex-1" />
          <button
            onClick={() => setDark((v) => !v)}
            className="grid h-7 w-7 place-items-center rounded-full text-muted-foreground transition-all duration-150 hover:bg-black/[0.05] hover:text-foreground active:scale-90 dark:hover:bg-white/[0.08]"
            title="切换深浅色"
          >
            {dark ? <Sun className="h-[14px] w-[14px]" /> : <Moon className="h-[14px] w-[14px]" />}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-28">
        {/* 01 快速面板 */}
        <Section
          no="01 / 快速面板"
          title="Spotlight 式交互，视觉全面减重"
          desc="搜索框裸奔、选中用 4.5% 浅灰填充、只留发丝分隔线、快捷键全部纯文本。下面是活的面板：悬停或点击后，整套键盘流都可以直接试。"
        >
          <div className="mb-5 flex flex-wrap items-center justify-center gap-1.5">
            {HINTS.map((h) => (
              <span key={h} className="mono rounded-full bg-black/[0.04] px-2.5 py-1 text-[10.5px] text-muted-foreground dark:bg-white/[0.07]">
                {h}
              </span>
            ))}
          </div>
          <div className="float-y flex justify-center">
            <ClipPanel autoActive />
          </div>
        </Section>

        {/* 02 状态与变体 */}
        <Section
          no="02 / 状态与变体"
          title="同一套令牌，四种状态"
          desc="深色模式直接切换令牌值；快速预览、多选批量、空状态复用同一面板组件，不新增视觉语言。"
        >
          <div className="grid gap-x-10 gap-y-12 lg:grid-cols-2">
            <div>
              <p className="mono mb-3 text-[11px] text-muted-foreground/70">深色模式</p>
              <div className="dark flex justify-center rounded-2xl bg-[#09090B] p-6">
                <ClipPanel />
              </div>
            </div>
            <div>
              <p className="mono mb-3 text-[11px] text-muted-foreground/70">快速预览（空格）</p>
              <div className="flex justify-center">
                <ClipPanel forceQuicklook />
              </div>
            </div>
            <div>
              <p className="mono mb-3 text-[11px] text-muted-foreground/70">多选批量操作</p>
              <div className="flex justify-center">
                <ClipPanel forceMulti={["1", "3", "5"]} />
              </div>
            </div>
            <div>
              <p className="mono mb-3 text-[11px] text-muted-foreground/70">空状态</p>
              <div className="flex justify-center">
                <ClipPanel forceEmpty />
              </div>
            </div>
          </div>
        </Section>

        {/* 03 设置窗口 */}
        <Section
          no="03 / 设置窗口"
          title="macOS 分区设置，控件全部原生语义"
          desc="侧栏 + 行式表单：Switch、分段控件、Slider、Select 均来自 shadcn/ui，发丝线分隔，无卡片套卡片。侧栏可点，控件全部可操作。"
        >
          <div className="flex justify-center">
            <SettingsWindow />
          </div>
        </Section>

        {/* 04 设计规范 */}
        <Section
          no="04 / 设计规范"
          title="令牌、字号、动效、键盘"
          desc="这套预览用到的全部设计参数——纯灰阶令牌（深浅双值）、字号阶梯、弹簧动效曲线与完整键盘映射。"
        >
          <SpecSheet />
        </Section>
      </main>

      <footer className="border-t border-black/[0.05] py-6 dark:border-white/[0.07]">
        <p className="mono text-center text-[11px] text-muted-foreground/60">
          ClipForge · Tauri v2 + React 19 · 纯灰阶 / 轻量选中 / 弹簧动效 / 键盘优先
        </p>
      </footer>
    </div>
  )
}
