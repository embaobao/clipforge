import { useState, type ReactNode } from "react"
import {
  Settings2, Keyboard, History, Scissors, Monitor, Info, Download, RotateCcw,
} from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"

const NAV = [
  { key: "general", label: "通用", icon: Settings2 },
  { key: "hotkey", label: "快捷键", icon: Keyboard },
  { key: "history", label: "历史与隐私", icon: History },
  { key: "snippet", label: "片段与文件夹", icon: Scissors },
  { key: "appearance", label: "外观", icon: Monitor },
  { key: "about", label: "关于", icon: Info },
]

function Row({ label, desc, children }: { label: string; desc?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-8 py-3">
      <div className="min-w-0">
        <p className="text-[13px]">{label}</p>
        {desc && <p className="mt-0.5 text-[11.5px] leading-relaxed text-muted-foreground">{desc}</p>}
      </div>
      <div className="flex shrink-0 items-center gap-2">{children}</div>
    </div>
  )
}

export function SettingsWindow({ className }: { className?: string }) {
  const [nav, setNav] = useState("general")
  const [cap, setCap] = useState([2000])

  return (
    <div className={cn("panel-in w-[680px] overflow-hidden rounded-[12px] bg-card window-shadow", className)}>
      {/* 标题栏 */}
      <div className="relative flex h-11 items-center justify-center border-b border-black/[0.05] dark:border-white/[0.07]">
        <div className="absolute left-4 flex items-center gap-2">
          <span className="h-[11px] w-[11px] rounded-full bg-[#FF5F57]" />
          <span className="h-[11px] w-[11px] rounded-full bg-[#FEBC2E]" />
          <span className="h-[11px] w-[11px] rounded-full bg-[#28C840]" />
        </div>
        <span className="text-[13px] font-medium">设置</span>
      </div>

      <div className="flex">
        {/* 侧栏 */}
        <div className="w-[172px] shrink-0 space-y-px border-r border-black/[0.05] bg-black/[0.02] p-2 dark:border-white/[0.07] dark:bg-white/[0.03]">
          {NAV.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setNav(key)}
              className={cn(
                "flex h-8 w-full items-center gap-2 rounded-md px-2.5 text-[12.5px] transition-colors duration-100 active:scale-[0.98]",
                nav === key
                  ? "bg-black/[0.06] font-medium dark:bg-white/[0.1]"
                  : "text-muted-foreground hover:bg-black/[0.03] dark:hover:bg-white/[0.05]",
              )}
            >
              <Icon className="h-[13px] w-[13px]" strokeWidth={1.8} />
              {label}
            </button>
          ))}
        </div>

        {/* 内容 */}
        <div className="min-w-0 flex-1 px-5 py-2">
          <Row label="全局快捷键" desc="在任意应用中呼出 ClipForge 面板">
            <span className="mono rounded-md bg-black/[0.05] px-2 py-1 text-[11.5px] dark:bg-white/[0.08]">⌃ V</span>
            <Button variant="ghost" size="sm" className="h-7 rounded-md text-[12px] text-muted-foreground">
              重新录制
            </Button>
          </Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />
          <Row label="开机自动启动"><Switch defaultChecked /></Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />
          <Row label="在菜单栏显示图标"><Switch defaultChecked /></Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />
          <Row label="复制时播放提示音"><Switch /></Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />

          <Row label="主题">
            <ToggleGroup type="single" defaultValue="system" className="gap-0 rounded-lg bg-black/[0.04] p-0.5 dark:bg-white/[0.07]">
              {[{ v: "system", t: "跟随系统" }, { v: "light", t: "浅色" }, { v: "dark", t: "深色" }].map((o) => (
                <ToggleGroupItem
                  key={o.v} value={o.v}
                  className="h-6 rounded-[7px] px-2.5 text-[12px] data-[state=on]:bg-white data-[state=on]:shadow-sm dark:data-[state=on]:bg-white/[0.14]"
                >
                  {o.t}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          </Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />

          <Row label="列表密度" desc="紧凑模式每屏可显示 9 条结果">
            <ToggleGroup type="single" defaultValue="cozy" className="gap-0 rounded-lg bg-black/[0.04] p-0.5 dark:bg-white/[0.07]">
              {[{ v: "compact", t: "紧凑" }, { v: "cozy", t: "舒适" }].map((o) => (
                <ToggleGroupItem
                  key={o.v} value={o.v}
                  className="h-6 rounded-[7px] px-2.5 text-[12px] data-[state=on]:bg-white data-[state=on]:shadow-sm dark:data-[state=on]:bg-white/[0.14]"
                >
                  {o.t}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          </Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />

          <Row label="历史容量" desc="超出后自动清理最早的记录">
            <Slider value={cap} onValueChange={setCap} min={100} max={5000} step={100} className="w-36" />
            <span className="mono w-16 text-right text-[11.5px] text-muted-foreground">
              {cap[0].toLocaleString()} 条
            </span>
          </Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />

          <Row label="自动清理">
            <Select defaultValue="30">
              <SelectTrigger className="h-7 w-[104px] rounded-lg text-[12px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                <SelectItem value="never">从不</SelectItem>
                <SelectItem value="7">7 天前</SelectItem>
                <SelectItem value="30">30 天前</SelectItem>
                <SelectItem value="90">90 天前</SelectItem>
              </SelectContent>
            </Select>
          </Row>
          <div className="border-t border-black/[0.04] dark:border-white/[0.06]" />

          <Row label="粘贴目标" desc="回贴内容发送到的应用">
            <Select defaultValue="front">
              <SelectTrigger className="h-7 w-[136px] rounded-lg text-[12px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                <SelectItem value="front">当前前台应用</SelectItem>
                <SelectItem value="last">上次使用的应用</SelectItem>
                <SelectItem value="ask">每次询问</SelectItem>
              </SelectContent>
            </Select>
          </Row>

          {/* 底部 */}
          <div className="mt-1 flex items-center justify-between border-t border-black/[0.05] py-3 dark:border-white/[0.07]">
            <span className="mono text-[10.5px] text-muted-foreground/70">ClipForge v0.5.2 (42)</span>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm" className="h-7 rounded-md px-2 text-[12px] text-muted-foreground">
                <RotateCcw className="mr-1 h-3 w-3" /> 恢复默认
              </Button>
              <Button variant="ghost" size="sm" className="h-7 rounded-md px-2 text-[12px] text-muted-foreground">
                <Download className="mr-1 h-3 w-3" /> 导出数据…
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
