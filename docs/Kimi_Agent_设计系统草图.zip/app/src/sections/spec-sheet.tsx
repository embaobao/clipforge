import type { ReactNode } from "react"
const TOKENS = [
  { name: "背景 background", light: "#FFFFFF", dark: "#09090B", swL: "bg-white", swD: "dark:bg-[#09090B]" },
  { name: "面板材质 material", light: "白 78% + blur(28)", dark: "#1C1C1E 80%", swL: "bg-white/80", swD: "dark:bg-[#1C1C1E]/80" },
  { name: "前景 foreground", light: "#18181B", dark: "#FAFAFA", swL: "bg-[#18181B]", swD: "dark:bg-[#FAFAFA]" },
  { name: "次级文字 muted-fg", light: "#71717A", dark: "#A1A1AA", swL: "bg-[#71717A]", swD: "dark:bg-[#A1A1AA]" },
  { name: "选中底 accent", light: "黑 4.5%", dark: "白 7%", swL: "bg-black/[0.045]", swD: "dark:bg-white/[0.07]" },
  { name: "发丝分隔线", light: "黑 5%", dark: "白 7%", swL: "bg-black/[0.05]", swD: "dark:bg-white/[0.07]" },
  { name: "主按钮 primary", light: "#18181B", dark: "#FAFAFA", swL: "bg-[#18181B]", swD: "dark:bg-[#FAFAFA]" },
]

const TYPE_SCALE = [
  { size: "11px", usage: "辅助信息 / 快捷键（mono）", sample: "Safari · 18 分钟前", cls: "text-[11px]" },
  { size: "12.5px", usage: "设置正文 / 菜单项", sample: "粘贴为纯文本", cls: "text-[12.5px]" },
  { size: "13px", usage: "列表主文本", sample: "选中态用浅灰填充", cls: "text-[13px]" },
  { size: "15px", usage: "搜索输入", sample: "搜索剪贴板历史…", cls: "text-[15px]" },
  { size: "20px+", usage: "区块标题（tracking -0.02em）", sample: "快速面板", cls: "text-[20px] font-semibold tracking-tight" },
]

const MOTION = [
  { name: "按压反馈", value: "scale(0.98) · 100ms ease-out", note: "pointer-down 即时，无延迟" },
  { name: "行选中", value: "背景色过渡 · 100ms", note: "仅 color/background，无 transform" },
  { name: "面板弹出", value: "450ms cubic-bezier(0.32, 0.72, 0, 1)", note: "translateY(12) + scale(0.965) → 归位" },
  { name: "菜单展开", value: "180ms · 从触发点缩放", note: "Radix origin-aware 动画" },
  { name: "行进入", value: "120ms opacity · 20ms 级联", note: "列表不过度编排" },
  { name: "降级", value: "prefers-reduced-motion / transparency", note: "自动关闭动画与材质模糊" },
]

const KEYS = [
  ["↑ ↓", "移动选中"], ["⏎", "复制并粘贴"], ["1–9", "直接粘贴第 n 条"],
  ["空格", "快速预览"], ["/", "聚焦搜索框"], ["⌘K", "全部操作菜单"],
  ["⌘D", "收藏"], ["⌘P", "固定到顶部"], ["⇧⏎", "粘贴为纯文本"], ["esc", "逐层退出"],
]

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="overflow-hidden rounded-xl border border-black/[0.06] dark:border-white/[0.08]">
      <div className="border-b border-black/[0.05] px-4 py-2.5 dark:border-white/[0.07]">
        <span className="mono text-[11px] uppercase tracking-[0.08em] text-muted-foreground">{title}</span>
      </div>
      <div className="divide-y divide-black/[0.04] dark:divide-white/[0.06]">{children}</div>
    </div>
  )
}

export function SpecSheet() {
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      {/* 令牌 */}
      <Block title="色彩令牌 · 纯灰阶">
        {TOKENS.map((t) => (
          <div key={t.name} className="flex items-center gap-3 px-4 py-2.5">
            <span className="flex overflow-hidden rounded-md border border-black/[0.06] dark:border-white/[0.1]">
              <span className={`h-5 w-8 ${t.swL}`} />
              <span className={`h-5 w-8 ${t.swD}`} />
            </span>
            <span className="flex-1 text-[12.5px]">{t.name}</span>
            <span className="mono text-right text-[10.5px] leading-tight text-muted-foreground">
              {t.light}<br />{t.dark}
            </span>
          </div>
        ))}
      </Block>

      {/* 字号 */}
      <Block title="字号阶梯 · SF 系统字">
        {TYPE_SCALE.map((t) => (
          <div key={t.size} className="flex items-baseline gap-4 px-4 py-2.5">
            <span className="mono w-12 shrink-0 text-[10.5px] text-muted-foreground">{t.size}</span>
            <span className={`flex-1 truncate ${t.cls}`}>{t.sample}</span>
            <span className="shrink-0 text-[11px] text-muted-foreground/70">{t.usage}</span>
          </div>
        ))}
        <div className="flex items-baseline gap-4 px-4 py-2.5">
          <span className="mono w-12 shrink-0 text-[10.5px] text-muted-foreground">圆角</span>
          <span className="flex-1 text-[12px] text-muted-foreground">行 8 · 卡片 10 · 面板 14 · 圆形按钮 999</span>
          <span className="mono shrink-0 text-[10.5px] text-muted-foreground/70">间距 4px 网格</span>
        </div>
      </Block>

      {/* 动效 */}
      <Block title="动效 · 弹簧曲线">
        {MOTION.map((m) => (
          <div key={m.name} className="flex items-center gap-4 px-4 py-2.5">
            <span className="w-20 shrink-0 text-[12.5px]">{m.name}</span>
            <span className="mono flex-1 truncate text-[11px] text-muted-foreground">{m.value}</span>
            <span className="shrink-0 text-[11px] text-muted-foreground/70">{m.note}</span>
          </div>
        ))}
      </Block>

      {/* 键盘 */}
      <Block title="键盘速查 · 全程不离键">
        <div className="grid grid-cols-2 gap-x-6">
          {KEYS.map(([k, v]) => (
            <div key={k} className="flex items-center gap-3 px-4 py-2">
              <span className="mono w-10 shrink-0 text-[11px]">{k}</span>
              <span className="text-[12px] text-muted-foreground">{v}</span>
            </div>
          ))}
        </div>
      </Block>
    </div>
  )
}
