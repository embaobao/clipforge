import { useEffect, useMemo, useRef, useState } from "react"
import { toast } from "sonner"
import {
  Search, Clock, Star, Scissors, MoreHorizontal, Type, Image as ImageIcon,
  Link2, FileText, Table2, Check, Pin, SearchX,
} from "lucide-react"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
  DropdownMenuShortcut, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

/* ---------------- 数据 ---------------- */

type ClipType = "text" | "image" | "link" | "doc" | "table"
interface Clip {
  id: string
  type: ClipType
  content: string
  meta: string
  group: string
  star?: boolean
  snip?: boolean
  pin?: boolean
}

const CLIPS: Clip[] = [
  { id: "1", type: "text", content: "选中态用浅灰填充 bg-accent，去掉描边和黑块", meta: "VS Code · 2 分钟前", group: "今天", star: true },
  { id: "2", type: "link", content: "https://ui.shadcn.com/docs/components", meta: "Safari · 18 分钟前", group: "今天" },
  { id: "3", type: "image", content: "界面截图 — Spotlight 搜索.png", meta: "截图 · 32 分钟前 · 2.1 MB", group: "今天" },
  { id: "4", type: "text", content: "pnpm dlx shadcn@latest add command kbd", meta: "终端 · 1 小时前", group: "今天" },
  { id: "5", type: "doc", content: "需求文档 v3 — 交互更便捷优雅，视觉减重", meta: "Pages · 1 小时前", group: "今天", pin: true },
  { id: "6", type: "text", content: "边框减半：只保留发丝分隔线，搜索框裸奔", meta: "备忘录 · 昨天 21:14", group: "昨天" },
  { id: "7", type: "link", content: "github.com/emilkowalski/skills — apple-design", meta: "Safari · 昨天 18:40", group: "昨天" },
  { id: "8", type: "table", content: "Q3 复制频次统计 — 1,284 次 / 日均 92", meta: "Numbers · 昨天 15:02", group: "昨天" },
  { id: "9", type: "text", content: "常用回复：收到，我今晚前给到你初稿。", meta: "片段 · 工作", group: "片段", snip: true },
  { id: "10", type: "text", content: "收件地址：上海市徐汇区漕河泾开发区 …", meta: "片段 · 个人", group: "片段", snip: true, star: true },
]

const TYPE_ICON = {
  text: Type, image: ImageIcon, link: Link2, doc: FileText, table: Table2,
} as const

const SCOPES = [
  { key: "all", label: "历史", icon: Clock },
  { key: "star", label: "收藏", icon: Star },
  { key: "snip", label: "片段", icon: Scissors },
  { key: "more", label: "更多", icon: MoreHorizontal },
] as const

/* ---------------- 面板 ---------------- */

interface PanelProps {
  autoActive?: boolean
  initialQuery?: string
  forceQuicklook?: boolean
  forceMulti?: string[]
  forceEmpty?: boolean
  className?: string
}

export function ClipPanel({
  autoActive, initialQuery = "", forceQuicklook, forceMulti, forceEmpty, className,
}: PanelProps) {
  const [query, setQuery] = useState(initialQuery)
  const [scope, setScope] = useState<string>("all")
  const [sel, setSel] = useState(0)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [quicklook, setQuicklook] = useState(!!forceQuicklook)
  const [menuOpen, setMenuOpen] = useState(false)
  const [active, setActive] = useState(!!autoActive)
  const inputRef = useRef<HTMLInputElement>(null)

  const visible = useMemo(() => {
    if (forceEmpty) return []
    let list = CLIPS
    if (scope === "star") list = list.filter((c) => c.star)
    if (scope === "snip") list = list.filter((c) => c.snip)
    if (scope === "more") list = list.filter((c) => c.type === "image" || c.type === "link")
    const q = query.trim().toLowerCase()
    if (q) list = list.filter((c) => c.content.toLowerCase().includes(q))
    return list
  }, [query, scope, forceEmpty])

  const groups = useMemo(() => {
    const out: { name: string; items: (Clip & { idx: number })[] }[] = []
    visible.forEach((c, idx) => {
      const g = out.find((x) => x.name === c.group)
      const item = { ...c, idx }
      if (g) g.items.push(item)
      else out.push({ name: c.group, items: [item] })
    })
    return out
  }, [visible])

  const clampedSel = Math.min(sel, Math.max(visible.length - 1, 0))
  const current = visible[clampedSel]
  const multi = forceMulti ?? []

  const copy = (clip?: Clip) => {
    if (!clip) return
    try { navigator.clipboard?.writeText(clip.content) } catch { /* iframe 环境忽略 */ }
    setCopiedId(clip.id)
    toast("已复制到剪贴板", {
      description: clip.content.length > 42 ? clip.content.slice(0, 42) + "…" : clip.content,
    })
    window.setTimeout(() => setCopiedId((v) => (v === clip.id ? null : v)), 1400)
  }

  const menuAction = (label: string) => toast(label, { description: current?.content.slice(0, 42) })

  /* 键盘：Spotlight 模型 */
  useEffect(() => {
    if (!active) return
    const onKey = (e: KeyboardEvent) => {
      const typing = document.activeElement === inputRef.current
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault(); setMenuOpen((v) => !v); return
      }
      if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, visible.length - 1)) }
      else if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)) }
      else if (e.key === "Enter") { e.preventDefault(); copy(current) }
      else if (e.key === "Escape") {
        if (menuOpen) setMenuOpen(false)
        else if (quicklook) setQuicklook(false)
        else if (typing && query) setQuery("")
        else if (typing) inputRef.current?.blur()
      }
      else if (e.key === " " && !typing) { e.preventDefault(); setQuicklook((v) => !v) }
      else if (e.key === "/" && !typing) { e.preventDefault(); inputRef.current?.focus() }
      else if (/^[1-9]$/.test(e.key) && !typing && !e.metaKey && !e.ctrlKey) {
        const n = parseInt(e.key, 10) - 1
        if (visible[n]) copy(visible[n])
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  })

  const scopeClick = (key: string, label: string) => {
    setScope(key); setSel(0)
    if (key === "more") toast("更多筛选", { description: "图片 / 链接 / 文件 / 应用来源" })
    else if (label) { /* 静默切换 */ }
  }

  return (
    <div
      className={cn(
        "panel-in w-[480px] overflow-hidden rounded-[14px] material panel-shadow",
        className,
      )}
      onMouseEnter={() => setActive(true)}
      onMouseLeave={() => setActive(false)}
    >
      {/* 搜索栏：裸奔无边框 */}
      <div className="flex h-[52px] items-center gap-3 px-4">
        <Search className="h-[15px] w-[15px] shrink-0 text-muted-foreground/70" strokeWidth={2} />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => { setQuery(e.target.value); setSel(0) }}
          onFocus={() => setActive(true)}
          placeholder="搜索剪贴板历史…"
          className="h-full flex-1 bg-transparent text-[15px] tracking-[-0.01em] outline-none placeholder:text-muted-foreground/50"
        />
        <div className="flex items-center gap-1">
          {SCOPES.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              title={label}
              onClick={() => scopeClick(key, label)}
              className={cn(
                "grid h-7 w-7 place-items-center rounded-full transition-all duration-150 active:scale-90",
                scope === key
                  ? "bg-foreground text-background"
                  : "text-muted-foreground/70 hover:bg-black/[0.05] hover:text-foreground dark:hover:bg-white/[0.08]",
              )}
            >
              <Icon className="h-[13px] w-[13px]" strokeWidth={2} />
            </button>
          ))}
        </div>
      </div>

      <div className="border-t border-black/[0.05] dark:border-white/[0.07]" />

      {/* 快速预览（空格） */}
      {quicklook && current && (
        <div className="row-in mx-2 mt-2 rounded-[10px] bg-black/[0.03] p-3.5 dark:bg-white/[0.05]">
          <div className="flex items-start gap-3">
            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-[8px] bg-black/[0.05] dark:bg-white/[0.08]">
              {(() => { const I = TYPE_ICON[current.type]; return <I className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.8} /> })()}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[13px] leading-relaxed">{current.content}</p>
              <p className="mono mt-1.5 text-[11px] text-muted-foreground/80">
                {current.meta} · {current.content.length} 字符
              </p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-1.5 border-t border-black/[0.05] pt-2.5 dark:border-white/[0.07]">
            <Button size="sm" className="h-6 rounded-md px-2 text-[11.5px]" onClick={() => copy(current)}>
              粘贴 <span className="mono ml-1 opacity-60">⏎</span>
            </Button>
            <Button variant="ghost" size="sm" className="h-6 rounded-md px-2 text-[11.5px] text-muted-foreground" onClick={() => menuAction("已纯文本粘贴")}>
              纯文本 <span className="mono ml-1 opacity-60">⇧⏎</span>
            </Button>
            <Button variant="ghost" size="sm" className="h-6 rounded-md px-2 text-[11.5px] text-muted-foreground" onClick={() => menuAction("已收藏")}>
              收藏 <span className="mono ml-1 opacity-60">⌘D</span>
            </Button>
          </div>
        </div>
      )}

      {/* 结果列表 */}
      <div className="thin-scroll max-h-[308px] overflow-y-auto p-1.5">
        {visible.length === 0 ? (
          <div className="flex flex-col items-center gap-2.5 py-12 text-center">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-black/[0.04] dark:bg-white/[0.07]">
              <SearchX className="h-4 w-4 text-muted-foreground" strokeWidth={1.8} />
            </div>
            <p className="text-[13px] font-medium">没有匹配的结果</p>
            <p className="text-[12px] text-muted-foreground">
              换个关键词，或按 <span className="mono">⌘N</span> 把当前内容存为新片段
            </p>
            <Button variant="outline" size="sm" className="mt-1 h-7 rounded-lg text-[12px]" onClick={() => menuAction("已新建片段")}>
              新建片段 <span className="mono ml-1 text-muted-foreground">⌘N</span>
            </Button>
          </div>
        ) : (
          groups.map((g) => (
            <div key={g.name}>
              <div className="flex items-baseline justify-between px-3 pb-1 pt-2.5">
                <span className="text-[11px] font-medium text-muted-foreground/80">{g.name}</span>
                <span className="mono text-[10.5px] text-muted-foreground/50">{g.items.length}</span>
              </div>
              {g.items.map((clip) => {
                const Icon = TYPE_ICON[clip.type]
                const isSel = clip.idx === clampedSel
                const isCopied = copiedId === clip.id
                const isMulti = multi.includes(clip.id)
                return (
                  <div
                    key={clip.id}
                    onClick={() => copy(clip)}
                    onMouseEnter={() => setSel(clip.idx)}
                    className={cn(
                      "group row-in relative flex h-11 cursor-default items-center gap-3 rounded-lg px-2 transition-colors duration-100 active:scale-[0.99]",
                      (isSel || isMulti) && "bg-black/[0.045] dark:bg-white/[0.07]",
                    )}
                    style={{ animationDelay: `${clip.idx * 20}ms` }}
                  >
                    <div className="grid h-7 w-7 shrink-0 place-items-center rounded-[7px] bg-black/[0.04] dark:bg-white/[0.07]">
                      <Icon className="h-[13.5px] w-[13.5px] text-muted-foreground" strokeWidth={1.8} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] leading-tight tracking-[-0.005em]">
                        {clip.pin && <Pin className="mr-1 inline h-3 w-3 -translate-y-px text-muted-foreground" strokeWidth={2} />}
                        {clip.content}
                      </p>
                      <p className="mt-0.5 truncate text-[11px] text-muted-foreground/70">{clip.meta}</p>
                    </div>
                    {/* 右侧：序号 / ⏎ / 已复制；悬停替换为快捷操作 */}
                    <div className="flex shrink-0 items-center gap-0.5">
                      {isCopied ? (
                        <span className="row-in flex items-center gap-1 text-[11px] text-muted-foreground">
                          <Check className="h-3.5 w-3.5" strokeWidth={2.2} /> 已复制
                        </span>
                      ) : (
                        <>
                          <span className="mono text-[11px] text-muted-foreground/50 group-hover:hidden">
                            {isSel ? "⏎" : clip.idx < 9 ? clip.idx + 1 : ""}
                          </span>
                          <span className="hidden items-center gap-0.5 group-hover:flex">
                            {[
                              { icon: Star, label: "收藏", fn: () => menuAction("已收藏") },
                              { icon: Pin, label: "固定", fn: () => menuAction("已固定到顶部") },
                              { icon: MoreHorizontal, label: "更多", fn: () => setMenuOpen(true) },
                            ].map(({ icon: A, label, fn }) => (
                              <button
                                key={label}
                                title={label}
                                onClick={(e) => { e.stopPropagation(); fn() }}
                                className="grid h-6 w-6 place-items-center rounded-md text-muted-foreground transition-all duration-100 hover:bg-black/[0.06] hover:text-foreground active:scale-90 dark:hover:bg-white/[0.1]"
                              >
                                <A className="h-3 w-3" strokeWidth={2} />
                              </button>
                            ))}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          ))
        )}
      </div>

      {/* 底栏：发丝线 + 纯文本快捷键 */}
      <div className="flex h-9 items-center justify-between border-t border-black/[0.05] px-3.5 dark:border-white/[0.07]">
        {multi.length > 0 ? (
          <>
            <span className="mono text-[11px] text-muted-foreground">已选 {multi.length} 项</span>
            <span className="mono text-[10.5px] text-muted-foreground/70">
              ⏎ 合并粘贴 · ⌫ 删除 · esc 取消
            </span>
          </>
        ) : (
          <>
            <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
              <DropdownMenuTrigger asChild>
                <button className="mono rounded-md px-1.5 py-0.5 text-[11px] text-muted-foreground transition-colors hover:bg-black/[0.05] hover:text-foreground dark:hover:bg-white/[0.08]">
                  {visible.length} 条 · ⌘K 全部操作
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" side="top" className="w-52 rounded-xl p-1">
                <DropdownMenuItem className="rounded-lg text-[12.5px]" onSelect={() => menuAction("已纯文本粘贴")}>
                  粘贴为纯文本 <DropdownMenuShortcut className="mono">⇧⏎</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuItem className="rounded-lg text-[12.5px]" onSelect={() => menuAction("已固定到顶部")}>
                  固定到顶部 <DropdownMenuShortcut className="mono">⌘P</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuItem className="rounded-lg text-[12.5px]" onSelect={() => menuAction("已收藏")}>
                  收藏 <DropdownMenuShortcut className="mono">⌘D</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="opacity-60" />
                <DropdownMenuItem className="rounded-lg text-[12.5px]" onSelect={() => menuAction("已新建片段")}>
                  新建片段 <DropdownMenuShortcut className="mono">⌘N</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuItem className="rounded-lg text-[12.5px]" onSelect={() => menuAction("已移到文件夹")}>
                  移到文件夹…
                </DropdownMenuItem>
                <DropdownMenuSeparator className="opacity-60" />
                <DropdownMenuItem className="rounded-lg text-[12.5px] text-destructive focus:text-destructive" onSelect={() => menuAction("已删除")}>
                  删除 <DropdownMenuShortcut className="mono">⌫</DropdownMenuShortcut>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <span className="mono text-[10.5px] text-muted-foreground/70">
              ↑↓ 浏览 · ⏎ 粘贴 · 空格 预览 · / 搜索
            </span>
          </>
        )}
      </div>
    </div>
  )
}
